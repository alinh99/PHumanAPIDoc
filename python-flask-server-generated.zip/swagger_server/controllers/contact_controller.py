import connexion
import six

from swagger_server.models.inline_response5001 import InlineResponse5001  # noqa: E501
from swagger_server import util


def employee_employee_id_list_get(employee_id):  # noqa: E501
    """Get Employee Information

     # noqa: E501

    :param employee_id: 
    :type employee_id: int

    :rtype: None
    """
    return 'do some magic!'
