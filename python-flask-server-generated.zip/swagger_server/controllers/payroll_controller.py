import connexion
import six

from swagger_server.models.inline_response5001 import InlineResponse5001  # noqa: E501
from swagger_server import util


def payroll_detail_employee_id_list_get(employee_id):  # noqa: E501
    """Get Payroll List Details

     # noqa: E501

    :param employee_id: 
    :type employee_id: int

    :rtype: None
    """
    return 'do some magic!'


def payroll_employee_idlist_get(employee_id):  # noqa: E501
    """Get Payroll List

     # noqa: E501

    :param employee_id: 
    :type employee_id: int

    :rtype: None
    """
    return 'do some magic!'
