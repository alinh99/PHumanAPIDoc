import connexion
import six

from swagger_server.models.inline_response4001 import InlineResponse4001  # noqa: E501
from swagger_server.models.inline_response5001 import InlineResponse5001  # noqa: E501
from swagger_server import util


def hour_all_salary_employee_id_calculation_get(employee_id):  # noqa: E501
    """Calculate Sum of Salary Based on Hours

     # noqa: E501

    :param employee_id: 
    :type employee_id: int

    :rtype: None
    """
    return 'do some magic!'


def hour_all_salary_employee_id_list_get(employee_id):  # noqa: E501
    """Get Total Hour Salary

     # noqa: E501

    :param employee_id: 
    :type employee_id: int

    :rtype: None
    """
    return 'do some magic!'


def hour_detail_salary_employee_id_calculation_get(employee_id):  # noqa: E501
    """Calculate Detail Salary Based on Hours

     # noqa: E501

    :param employee_id: 
    :type employee_id: int

    :rtype: None
    """
    return 'do some magic!'


def hour_detail_salary_employee_id_list_get(employee_id, id):  # noqa: E501
    """Get Detail Hour Salary

     # noqa: E501

    :param employee_id: 
    :type employee_id: int
    :param id: 
    :type id: int

    :rtype: None
    """
    return 'do some magic!'


def productivity_sum_employee_id_calculation_get(employee_id):  # noqa: E501
    """Calculate productivity

     # noqa: E501

    :param employee_id: 
    :type employee_id: int

    :rtype: None
    """
    return 'do some magic!'


def productivity_sum_salary_employee_id_calculation_get(employee_id):  # noqa: E501
    """Calculate Salary by productivity

     # noqa: E501

    :param employee_id: 
    :type employee_id: int

    :rtype: None
    """
    return 'do some magic!'


def productivity_sum_salary_employee_id_list_get(employee_id):  # noqa: E501
    """Get Sum Salary based on Productivity

     # noqa: E501

    :param employee_id: 
    :type employee_id: int

    :rtype: None
    """
    return 'do some magic!'
